# pages/eventos.py
import reflex as rx
from datetime import date
from controllers.event_state import EventState

BG      = "#FFF8E7"     # beige
BLUE    = "#0033A0"     # azul bandera
RED     = "#D22630"     # rojo bandera
HEADERS = ["Título", "Fecha", "Ciudad", "Categoría"]

@rx.page(route="/", on_load=[EventState.load])
def eventos() -> rx.Component:                                           # noqa: N802
    # ---------- fila ----------
    def row(ev):
        return rx.table.row(
            rx.table.cell(ev["titulo"],    color="#0D0D0D"),   # texto casi negro
            rx.table.cell(ev["fecha"],     color="#0D0D0D"),
            rx.table.cell(ev["ciudad"],    color="#0D0D0D"),
            rx.table.cell(ev["categoria"], color="#0D0D0D"),
            bg="#F4F6FC",                  # celeste claro
            _hover=dict(bg="#D9E6FF"),
            border_bottom="1px solid #E0E0E0"  # línea divisoria sutil
        )

    # ---------- paginador ----------
    nav = rx.hstack(
        rx.button(
            "Anterior",
            on_click=EventState.prev_page,
            is_disabled=EventState.offset <= 0,
            bg=BLUE, color="white",
        ),
        rx.text(  # centrado
            EventState.current_page, " / ", EventState.num_total_pages,
            font_weight="bold",
        ),
        rx.button(
            "Siguiente",
            on_click=EventState.next_page,
            is_disabled=EventState.offset + EventState.limit >= EventState.total_items,
            bg=BLUE, color="white",
        ),
        justify="center",
        spacing="4",
        width="100%",
    )

    # ---------- vista ----------
    return rx.box(
        rx.vstack(
            # título
            rx.text("Calendario Cultural — Tekovia Guasu",
                    size="8", weight="bold", color=BLUE),

            # formulario
            rx.form(
                rx.hstack(
                    rx.input(id="titulo", placeholder="Título", w=["100%","25%"]),
                    rx.input(
                        id="fecha",
                        type_="date",
                        default_value=date.today().isoformat(),   # ✔ editable
                        width="25%",
                    ),
                    rx.input(id="ciudad", placeholder="Ciudad",  w=["100%","20%"]),
                    rx.input(id="categoria", placeholder="Categoría", w=["100%","20%"]),
                    rx.button("Agregar", type_="submit", bg=RED, color="white"),
                    spacing="3", wrap="wrap", w="100%",
                ),
                on_submit=EventState.process_form,
                bg="white", p="5", border_radius="10", w="100%",
            ),

            # tabla
            rx.table.root(
                rx.table.header(
                    rx.table.row(*[rx.table.column_header_cell(h, color=BLUE)
                                   for h in HEADERS])),
                rx.table.body(rx.foreach(EventState.events, row)),
                width="100%", bg="white", border_radius="10",
            ),

            nav,
            spacing="6",
            w="100%", max_w="1200px",
        ),
        # container de página BEIGE al 100 %
        position="absolute", inset="0",
        display="flex", justify_content="center", align_items="flex-start",
        bg=BG, p="6",
    )
