﻿from .app import app as tekovia_app   # alias que Reflex exige
app = tekovia_app