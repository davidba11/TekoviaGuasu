# tekovia_app/tekovia_app.py
"""
Sub-módulo requerido por Reflex.
Exporta el objeto `app` definido en `tekovia_app/app.py`.
"""
from .app import app   # ← re-exporta el mismo objeto