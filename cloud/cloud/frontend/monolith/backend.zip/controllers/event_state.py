# controllers/event_state.py
import reflex as rx
from sqlmodel import Session, select, create_engine
from models.event import Event
import httpx, os, reflex as rx

API = os.getenv("BACKEND_URL", "http://localhost:8000")

engine = create_engine("postgresql+psycopg2://postgres:admin@localhost:5432/TekoviaGuasu")
Event.metadata.create_all(engine)


class EventState(rx.State):
    # ── datos en memoria ────────────────────────────────────────────────
    _all_rows: list[dict] = []     # todas las filas filtradas
    events: list[dict] = []    # ventana visible

    # ── paginación (igual que TransactionView) ──────────────────────────
    offset: int = 0
    limit: int  = 6
    total_items: int = 0

    @rx.var
    def current_page(self) -> int:
        return (self.offset // self.limit) + 1

    @rx.var
    def num_total_pages(self) -> int:
        return max((self.total_items + self.limit - 1) // self.limit, 1)

    # ---------- paginador ----------
    @rx.event
    def next_page(self):
        if self.offset + self.limit < self.total_items:
            self.offset += self.limit
            yield self.refresh_page()

    @rx.event
    def prev_page(self):
        if self.offset > 0:
            self.offset -= self.limit
            yield self.refresh_page()

    @rx.event
    def refresh_page(self):
        """Copia la porción visible de _all_rows a events."""
        self.events = self._all_rows[self.offset : self.offset + self.limit]
        self.set()

    # ── carga inicial y alta ────────────────────────────────────────────
    @rx.event
    async def load(self):
        async with httpx.AsyncClient() as c:
            rows = (await c.get(f"{API}/events")).json()
        self._all_rows = rows
        self.total_items = len(rows)
        self.offset = 0
        yield self.refresh_page()

    @rx.event
    async def process_form(self, form: dict):
        if not all(form.values()):
            yield rx.toast("Completa todos los campos")
            return
        async with httpx.AsyncClient() as c:
            await c.post(f"{API}/events", json=form)
        yield self.load()

    @rx.var
    def paged(self) -> list[dict]:
        return self.events
